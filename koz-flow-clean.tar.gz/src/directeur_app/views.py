from django.shortcuts import render
from django.views.generic import ListView, DeleteView, DetailView, CreateView, TemplateView, UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin #pour la connection requise et permission selon le role


from auth_app.forms import UserRegisterForm, ChangePasswordForm
from vehicul_app.forms import MarqueForm, VehiculForm
from products_app.forms import CategorieProductsForm, ProductsForm
class DirecteurDashboardView(LoginRequiredMixin,UserPassesTestMixin,TemplateView ):
    
    template_name = "directeur_templates/directeur.html"
    
    # test_func est une method qui vient de la classe UserPassTestMixin elle retourne la condition de permissité sur la View
    def test_func(self):
        # Seul le directeur ou superuser peut accéder
        return self.request.user.is_superuser or self.request.user.role == "directeur"
    
    
    # get_context_data est une methode de la class TemplateView permet d'ajouter et de return le context qui accecible depuis le template:
    # avec cette method depuis directeur.htlm on peut acceder au info User qui connecter 
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        context["directeur"] = self.request.user
        
        if "user_register_form" not in context:
            context["user_register_form"] = UserRegisterForm()
        
        if 'change_pass_form' not in context:
            context["change_pass_form"] = ChangePasswordForm()
            
        if 'marque_form' not in context:
            context["marque_form"] = MarqueForm()
        
        if "vehicul_form" not in context:
            context["vehicul_form"] = VehiculForm()
            
        if "create_product_form" not in context:
            context["create_product_form"] = ProductsForm()
        
        if "create_categorie_form" not in context:
            context["create_categorie_form"] = CategorieProductsForm()
            
        return context 
       
    

        
        
    
  
    
