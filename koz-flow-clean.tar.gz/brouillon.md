 <!-- commercial -->
📧 Email : nasserdevtest@gmail.com
nasserdevtest@gmail.com : s4MQaV31ux

 <!--Client-->
📧 Email : nasabsas@gmail.com
nasabsas@gmail.com : AYg3YZ02eG

livai@gmail.com : HTKWiITPI0


 <!--a href="{% url 'leads_app:document-update' doc.id %}">✏️</a -->

 commercial details doc: <div>
    <a href="{% url 'leads_app:document-update' document.id %}">✏️ Modifier statut</a>
    <a href="{% url 'leads_app:document-list' document.demande_financement.id %}">◀ Retour</a>
</div>

directeur details doc: <div>
       <a href="{% url 'leads_app:document-update' doc.id %}">✏️</a>
                
                <a href="{% url 'leads_app:document-delete' doc.id %}">🗑️</a>our</a>

                <a href="{% url 'leads_app:document-update' document.id %}">✏️ Modifier dossier</a>






                     {% for vehicul in vehicul_list  %}
        <li>{{ vehicul.marque }}</li>
        <li>{{ vehicul.modele }}</li>
        <li><img width="150" height="150" src="{{ vehicul.image_principale.url }}" alt="{{ vehicul.nom }}"></li>
        <li><a href="{% url 'vehicul_app:detail-vehicul' vehicul.pk %}">Voir les détails</a></li>
    {% empty %}
        <li>Aucune voiture disponible.</li>
    {% endfor %}
    </ul>
    {% if user.is_authenticated and user.is_superuser or user.role == "directeur" %}
        <a class="btn" href="{% url 'directeur_app:directeur-view' %}">retour au dashboard</a>
    {% endif %}
    <a href="{}"></a>




# maintenance_app/management/commands/rappel_maintenance.py
from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta
from django.core.mail import send_mail

class Command(BaseCommand):
    help = 'Envoie des rappels de maintenance J-7'

    def handle(self, *args, **kwargs):
        date_limite = timezone.now().date() + timedelta(days=7)
        maintenances = Maintenance.objects.filter(
            date_prochaine=date_limite,
            statut='planifiee',
            rappel_envoye=False
        )
        
        for m in maintenances:
            send_mail(
                subject="🔧 Rappel : votre maintenance approche - KOZ Services",
                message=f"Bonjour {m.client.nom_complet},\n\nVotre maintenance ({m.get_type_maintenance_display()}) est prévue dans 7 jours.\nMerci de confirmer votre disponibilité.",
                from_email=settings.EMAIL_HOST_USER,
                recipient_list=[m.client.email],
                fail_silently=False,
            )
            m.rappel_envoye = True
            m.save()
            self.stdout.write(f"Rappel envoyé à {m.client.email}")








    <!-- Résultats -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {% for vehicule in vehicul_list %}
        <div class="bg-white shadow rounded p-4">
            <img src="{{ vehicule.image_principale.url }}" width="160" height="160" class="w-full h-40 object-cover rounded mb-2">
            <h3 class="font-bold">{{ vehicule.marque.nom }} {{ vehicule.modele }}</h3>
            <p>{{ vehicule.annee }} - {{ vehicule.prix }} FCFA</p>
            <p class="text-sm text-gray-500">{{ vehicule.kilometrage }} km - {{ vehicule.get_carburant_display }}</p>
            {% if vehicule.disponible %}
                <span class="badge badge-success">✅ Disponible</span>
            {% else %}
                <span class="badge badge-error">❌ Vendu</span>
            {% endif %}
            <a href="{% url 'vehicul_app:detail-vehicul' vehicule.pk %}" class="btn btn-outline btn-sm mt-2">Voir détails</a>
        </div>
        {% empty %}
        <p class="text-gray-500 col-span-full text-center">Aucun véhicule trouvé.</p>
        {% endfor %}
    </div>
</div>


client_list_doc, meme chose comme les autre, deplace aussi les filtre dans le template principale et laisse slmt le resultat dans le partials
{% load static %}
{% load tailwind_tags %}
{% load humanize %}

client_list_doc.html:
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    {% tailwind_css %}
    <script src="{% static 'js/htmx.min.js' %}" defer></script>
    <link rel="stylesheet" href="{% static 'css/client_list_doc_style.css' %}">
    <title>Mes documents - KOZ Services</title>
</head>
<body class="bg-gray-100">

<div class="container mx-auto px-4 py-8 max-w-6xl">
    
    <!-- En-tête -->
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">📄 Mes documents</h1>
        <a href="{% url 'client_app:client-view' %}" class="btn btn-outline btn-sm">◀ Retour à mon espace</a>
    </div>

    <!-- Zone dynamique (filtres + liste) -->
    <div hx-get="{% url 'leads_app:document-list' %}" 
         hx-trigger="load" 
         hx-target="#document-list-container" 
         hx-swap="innerHTML">
        <div class="text-center py-10">Chargement...</div>
    </div>

</div>

</body>
</html>
le partials:
<div id="document-list-container">
    
    <!-- Filtres simples (optionnels) -->
    <div class="bg-white shadow rounded p-4 mb-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <select name="statut" 
                    hx-get="{% url 'leads_app:document-list' %}"
                    hx-target="#document-list-container"
                    hx-trigger="change"
                    class="select select-bordered w-full">
                <option value="">📌 Tous statuts</option>
                <option value="vide">Vide</option>
                <option value="incomplet">Incomplet</option>
                <option value="complet">Complet</option>
                <option value="valide">Validé</option>
                <option value="rejete">Rejeté</option>
            </select>

            <a href="{% url 'leads_app:document-list' %}" class="btn btn-outline">🔄 Réinitialiser</a>
        </div>
    </div>

    <!-- Liste des documents -->
    <div class="bg-white shadow rounded-lg overflow-hidden">
        <table class="min-w-full">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-6 py-3 text-left text-sm font-semibold">Type</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold">Statut</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold">Date upload</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold">Actions</th>
                </tr>
            </thead>
            <tbody>
                {% for doc in documents %}
                <tr class="border-t hover:bg-gray-50 transition">
                    <td class="px-6 py-4">{{ doc.get_type_document_display }}</td>
                    <td class="px-6 py-4">
                        <span class="badge 
                            {% if doc.statut_dossier == 'valide' %}badge-success
                            {% elif doc.statut_dossier == 'rejete' %}badge-error
                            {% else %}badge-warning{% endif %}">
                            {{ doc.get_statut_dossier_display }}
                        </span>
                        {% if doc.statut_dossier == "rejete" and doc.commentaire_rejet %}
                            <div class="text-xs text-red-500 mt-1">{{ doc.commentaire_rejet }}</div>
                        {% endif %}
                    </td>
                    <td class="px-6 py-4">{{ doc.date_upload|date:"d/m/Y H:i" }}</td>
                    <td class="px-6 py-4">
                        <a href="{% url 'leads_app:document-detail' doc.pk %}" class="btn btn-sm btn-outline">👁️ Détails</a>
                    </td>
                </tr>
                {% empty %}
                <tr>
                    <td colspan="4" class="px-6 py-8 text-center text-gray-500">
                        📭 Aucun document trouvé.
                    </td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    {% if is_paginated %}
    <div class="mt-6 flex justify-center">
        <div class="join">
            {% if page_obj.has_previous %}
                <a href="?page=1" class="join-item btn btn-sm">«</a>
                <a href="?page={{ page_obj.previous_page_number }}" class="join-item btn btn-sm">‹</a>
            {% endif %}
            <span class="join-item btn btn-sm btn-disabled">Page {{ page_obj.number }} / {{ page_obj.paginator.num_pages }}</span>
            {% if page_obj.has_next %}
                <a href="?page={{ page_obj.next_page_number }}" class="join-item btn btn-sm">›</a>
                <a href="?page={{ page_obj.paginator.num_pages }}" class="join-item btn btn-sm">»</a>
            {% endif %}
        </div>
    </div>
    {% endif %}
</div>



{% load static %}
{% for vehicule in vehicul_list %}

<div class="card">
    <div class="card-inner">
        <div class="content-card">
            <img src="{{ vehicule.image_principale.url }}" alt="{{ vehicule.marque.nom }}">
        </div>
        <div class="card-info">
            <h3>{{ vehicule.marque.nom }}</h3>
            <h5>{{ vehicule.modele }}</h5>
            <p class="prix">{{ vehicule.prix }} FCFA</p>
            <p class="dispo">
                {% if vehicule.disponible %}
                    ✅ Disponible
                {% else %}
                    ❌ Indisponible
                {% endif %}
            </p>
          <a  href="{% url 'vehicul_app:detail-vehicul' vehicule.pk %}">voir plus</a>
        </div>
        <div class="glow"></div>
    </div>
</div>

{% endfor %}



<div class="flex flex-wrap gap-3 pt-4 border-t border-gray-100">
    <a href="{% url 'commercial_app:accepter-offre' offre.id %}" class="btn-glow px-6 py-2 rounded-xl">
        <i class="fas fa-check-circle mr-2"></i>Accepter l'offre
    </a>
    <a href="{% url 'commercial_app:refuser-offre' offre.id %}" class="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-xl transition shadow-md">
        <i class="fas fa-times-circle mr-2"></i>Refuser l'offre
    </a>
    <a href="{% url 'commercial_app:negocier-offre' offre.id %}" class="bg-gray-600 hover:bg-gray-700 text-white px-6 py-2 rounded-xl transition">
        <i class="fas fa-comment-dots mr-2"></i>Négocier
    </a>
</div>





from pathlib import Path
import os
from dotenv import load_dotenv

load_dotenv()

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent


# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/5.2/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = os.getenv('SECRET_KEY')

# SECURITY WARNING: don't run with debug turned on in production!

DEBUG = False 

ALLOWED_HOSTS = os.getenv('ALLOWED_HOSTS', '').split(',')


# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.humanize',
    
    #'django_htmx',
    'formtools',
    
    #Tailwind_app
    'tailwind',
    'crispy_forms',
    'theme',
    
    #other_app
    'auth_app',
    'directeur_app',
    'comptable_app',
    'secretaire_app',
    'employee_app',
    'client_app',
    'chantier_app',
    'contrat_app',
    'dashboard_app',
    'home_app'
    
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'sanba_finflow.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR/"templates")],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'sanba_finflow.wsgi.application'


# Database
# https://docs.djangoproject.com/en/5.2/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR /'db' / 'db.sqlite3',
        
    }
}


# Password validation
# https://docs.djangoproject.com/en/5.2/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# Internationalization
# https://docs.djangoproject.com/en/5.2/topics/i18n/

LANGUAGE_CODE = 'fr-fr'
TIME_ZONE = 'Africa/Dakar'  # ou ton fuseau
USE_I18N = True
USE_L10N = True
USE_TZ = True  # TRÈS IMPORTANT !

# Format d'affichage par défaut
DATETIME_FORMAT = 'd/m/Y H:i:s'
DATE_FORMAT = 'd/m/Y'
TIME_FORMAT = 'H:i:s'


# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/5.2/howto/static-files/
MEDIA_URL = 'media/'
STATIC_URL = 'static/'



MEDIA_ROOT = os.path.join(BASE_DIR/"media")
STATIC_ROOT = os.path.join(BASE_DIR/"staticfiles")

STATICFILES_DIRS = [
    os.path.join(BASE_DIR/"sanba_finflow/static")
]

# URL de redirection APRÈS login réussi
LOGIN_REDIRECT_URL = '/'  # Ou '/dashboard/', '/home/', etc.

# URL de la page de login
LOGIN_URL = '/login/'  # ✅ Correct si tu as une vue à /login/

# Optionnel: URL de logout
LOGOUT_REDIRECT_URL = '/logout/'  # Où rediriger après logout


#auth_conf
AUTH_USER_MODEL= "auth_app.Personnel"

# Default primary key field type
# https://docs.djangoproject.com/en/5.2/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'


TAILWIND_APP_NAME = "theme"
INTERNAL_IPS = [
    "127.0.0.1"
                ]

CRISPY_ALLOWED_TEMPLATE_PACKS = "tailwind"
CRISPY_TEMPLATE_PACK = "tailwind"

NPM_BIN_PATH = r'C:\Program Files\nodejs\npm.cmd'

# Essaye avec SSL au lieu de TLS
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 465  # Port SSL
EMAIL_USE_SSL = True  # Au lieu de TLS
EMAIL_USE_TLS = False
EMAIL_HOST_USER = os.getenv('EMAIL_HOST_USER')
EMAIL_HOST_PASSWORD = os.getenv('EMAIL_HOST_PASSWORD') # Utilise un mot de passe d'application si l'authentification à deux facteurs est activée

# Sécurité CSRF pour HTTPS
CSRF_TRUSTED_ORIGINS = [
    'https://sanba-finflow.pro',
    'https://www.sanba-finflow.pro',
]

# Cookies sécurisés pour HTTPS uniquement
CSRF_COOKIE_SECURE = True
SESSION_COOKIE_SECURE = True

# Optionnel: protection additionnelle
CSRF_COOKIE_HTTPONLY = True
SESSION_COOKIE_HTTPONLY = True
CSRF_COOKIE_SAMESITE = 'Lax'
SESSION_COOKIE_SAMESITE = 'Lax'
root@sanbastructure:/opt/sanba/src/sanba_finflow#